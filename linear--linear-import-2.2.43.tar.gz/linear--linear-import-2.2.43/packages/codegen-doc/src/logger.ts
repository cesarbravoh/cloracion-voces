import { colorConsole } from "tracer";

/**
 * Default tracer logger
 */
export const logger = colorConsole();
