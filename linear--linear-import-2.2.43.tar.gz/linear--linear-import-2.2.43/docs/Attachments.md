# Visit [developers.linear.app](https://developers.linear.app/docs/graphql/attachments) for the most up to date documentation
