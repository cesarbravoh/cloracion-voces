# Visit [developers.linear.app](https://developers.linear.app/docs/graphql/webhooks) for the most up to date documentation
