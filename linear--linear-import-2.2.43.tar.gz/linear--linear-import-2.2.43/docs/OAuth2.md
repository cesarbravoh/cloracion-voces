# Visit [developers.linear.app](https://developers.linear.app/docs/oauth/authentication) for the most up to date documentation
